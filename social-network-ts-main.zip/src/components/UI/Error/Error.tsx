export const Error = () => {
    return <h1>Произошла ошибка</h1>
}