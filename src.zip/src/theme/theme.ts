import { colors } from "./colors";

export const theme = {
    colors:{...colors}
}

export const Theme = typeof theme